#ifndef FILA_H
#define FILA_H

#include <vector>
#include <queue>
#include <memory>
#include "Customer.h"

class Fila {
public:
    Fila(); // Constructor
    void generateQueue(); // Método para generar la cola de clientes
    void printCustomers() const; // Método para imprimir los clientes

private:
    std::queue<std::unique_ptr<Customer>> waitingQueue;
};

#endif
