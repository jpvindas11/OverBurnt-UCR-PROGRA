#ifndef RECIPE_H
#define RECIPE_H

#include <string>
#include <map>
#include <vector>
using namespace std;
class Recipe {
public:
    //name,prize,aprox time to prepare,aprox time to eat, ingredients...
   
    Recipe(const string& name, double price, double prepTime, double eatingTime, const map<string, int>& ingredients);
   
    vector<Recipe> loadRecipesFromCSV(const string &filename);
    string getName() const;
    double getPrice() const;
    double getPrepTime() const;
    double getEatingTime() const;
    map<string, int> getIngredients() const;

private:
    string name;
    double price;
    double prepTime;
    double eatingTime;
    map<string, int> ingredients;//mapa asocia cada ingrediente (cadena de caracteres) con una cantidad (entero)
};

#endif 