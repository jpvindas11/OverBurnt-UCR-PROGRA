#include "Kitchen.h"
#include <iostream>
#include <thread>
#include <chrono>
using namespace std;
Kitchen::Kitchen(Menu& menu, Inventory& inventory) : menu(menu), inventory(inventory) {}

void Kitchen::prepareDish(const string& recipeName) {
    Recipe recipe = menu.getRecipe(recipeName);
    if (!inventory.hasIngredients(recipe.getIngredients())) {
        cerr << "Not enough ingredients for " << recipeName << endl;
        return;
    }
    inventory.useIngredients(recipe.getIngredients());
    cout << "Preparing " << recipeName << endl;
    
    // Obtener el tiempo estimado de preparación de la receta
    double prepTime = recipe.getPrepTime();
    
    //tiempo de preparación podría aumentar o disminuir en un 10% como máximo.
    double PREP_DELAY=0.1;

    // Calcular un valor aleatorio entre -1 y 1
    int randomMultiplier = (rand() % 3) - 1; // Genera números entre -1 y 1
    
    // Calcular el tiempo ajustado de preparación según la fórmula
    double adjustedPrepTime = prepTime + (prepTime * randomMultiplier * PREP_DELAY);
    
    //tiempo minimo de preparacion vamos a decir que es 5 min
    int MIN_PREP_TIME=5;
    // Verificar si el tiempo calculado es negativo y ajustarlo si es necesario
    if (adjustedPrepTime < MIN_PREP_TIME) {
        adjustedPrepTime = MIN_PREP_TIME;
    }
    
    // Simular el tiempo de preparación
    this_thread::sleep_for(chrono::milliseconds(static_cast<int>(adjustedPrepTime * 1000)));
    
    cout << recipeName << " is ready!" << endl;
}