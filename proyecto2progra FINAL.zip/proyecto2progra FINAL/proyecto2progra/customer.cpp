#include "Customer.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <random>

Customer::Customer(const std::string& name, const std::vector<std::string>& order, int eatingTime)
    : name(name), order(order), eatingTime(eatingTime) {}

std::string Customer::getName() const {
    return name;
}

std::vector<std::string> Customer::getOrder() const {
    return order;
}

int Customer::getEatingTime() const {
    return eatingTime;
}

std::vector<std::string> getRandomOrder() {
    // Lista de posibles órdenes
    std::vector<std::vector<std::string>> possibleOrders = {
        {"Salad"},
        {"Hamburguesa"},
        {"Pinto"},
        {"ArrozConPollo"},
        {"Casado"},
        {"SopaDePollo"},
        {"Pasta"}
    };

    // Generar un índice aleatorio para seleccionar una orden
    int randomIndex = rand() % possibleOrders.size();
    return possibleOrders[randomIndex];
}
int Customer::getNum(){
    int randomNum = rand() % 15;
    return randomNum;
}

std::string getRandomName() {
    // Lista de nombres posibles
    std::vector<std::string> names = {"Alice","La Nasa","juan pa!", "Alberto", "Camilo","Betty", "Sergio Arturo Moya Valerin", "Mar", "Mainor andres castro", "Gregory"};

    // Generar un índice aleatorio para seleccionar un nombre
    int randomIndex = rand() % names.size();
    return names[randomIndex];
}

int getRandomEatingTime() {
    return rand() % 21 + 10; // Generar un número aleatorio entre 10 y 30 de lo que dura comiendo
}

Customer Customer::spawnRandomCustomer() {
    std::string name = getRandomName();
    std::vector<std::string> order = getRandomOrder();
    int eatingTime = getRandomEatingTime();
    return Customer(name, order, eatingTime);
}

