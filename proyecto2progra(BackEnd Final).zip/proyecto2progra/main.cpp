#include "Restaurant.h"
#include <iostream>


int main() {


    try {
        // Inicializar el restaurante con 5 mesas y archivos CSV para inventario y menú
        Restaurant restaurant(6);
        restaurant.runSimulation();
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
//cd C:\Users\Nardozayer18\Downloads\proyecto2progra
//g++ -o main main.cpp Inventory.cpp
//./main
//para compilar el correcto almacenamiento de la receta en el vector meta en la terminal:
//  g++ -std=c++17 -o main main.cpp Menu.cpp Recipe.cpp
// otra forma:  g++ -o main main.cpp Menu.cpp Recipe.cpp   
//para compilar el restaurante:  
//g++ -std=c++17 -o main main.cpp Restaurant.cpp Customer.cpp Table.cpp Menu.cpp Inventory.cpp Kitchen.cpp Recipe.cpp ThreadPool.h
