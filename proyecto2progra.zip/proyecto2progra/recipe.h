#ifndef RECIPE_H
#define RECIPE_H

#include <string>
#include <map>

class Recipe {
public:
    Recipe(const std::string& name, double price, double prepTime, double eatingTime, const std::map<std::string, int>& ingredients);

    std::string getName() const;
    double getPrice() const;
    double getPrepTime() const;
    double getEatingTime() const;
    std::map<std::string, int> getIngredients() const;

private:
    std::string name;
    double price;
    double prepTime;
    double eatingTime;
    std::map<std::string, int> ingredients;
};

#endif