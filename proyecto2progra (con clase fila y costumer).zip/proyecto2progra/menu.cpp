#include "Menu.h"
#include "Recipe.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <iostream>

Menu::Menu() {
    // Constructor implementation (if needed)
}

void Menu::loadFromCSV() {
    std::ifstream archivo("recipes.csv");
    if (!archivo.is_open()) {
        throw std::runtime_error("No se pudo abrir el archivo CSV");
    }

    std::string linea;
    char delimitador = ',';
    // Leemos la primer línea para descartarla, pues es el encabezado
    std::getline(archivo, linea);

    // Leemos todas las líneas
    while (std::getline(archivo, linea)) {
        std::stringstream stream(linea); // Convertir la cadena a un stream
        std::string nombre, precioStr, tiempoPrepStr, ingreStr, cantidadStr;
        double precio;
        double tiempoPreparacion;

        // Extraer los primeros valores de la fila
        std::getline(stream, nombre, delimitador);
        std::getline(stream, precioStr, delimitador);
        std::getline(stream, tiempoPrepStr, delimitador);

        try {
            precio = std::stod(precioStr);
            tiempoPreparacion = std::stod(tiempoPrepStr);
        } catch (const std::invalid_argument& e) {
            std::cerr << "Error de conversión: valores inválidos en la línea '" << linea << "'" << std::endl;
            continue; // O manejar el error según sea necesario
        }

        // Extraer ingredientes y cantidades
        std::getline(stream, ingreStr, delimitador);
        std::getline(stream, cantidadStr, delimitador);

        std::map<std::string, int> ingredientes;
        std::stringstream ingreStream(ingreStr);
        std::stringstream cantidadStream(cantidadStr);
        std::string ingrediente;
        std::string cantidad;

        while (std::getline(ingreStream, ingrediente, ';') && std::getline(cantidadStream, cantidad, ';')) {
            try {
                int cantidadInt = std::stoi(cantidad);
                ingredientes[ingrediente] = cantidadInt;
            } catch (const std::invalid_argument& e) {
                std::cerr << "Error de conversión: cantidad inválida para el ingrediente '" << ingrediente << "'" << std::endl;
                continue;
            }
        }

        // Crear y agregar la receta al vector
        Recipe receta(nombre, precio, tiempoPreparacion, 0, ingredientes);
        recipesList.push_back(receta);
    }

    archivo.close();
}

Recipe Menu::getRecipe(const std::string& name) const {
    for (const auto& recipe : recipesList) {
        if (recipe.getName() == name) {
            return recipe;
        }
    }
    throw std::runtime_error("Recipe not found");
}

void Menu::printRecipes() const {
    for (const auto& recipe : recipesList) {
        std::cout << "Nombre: " << recipe.getName() << std::endl;
        std::cout << "Precio: " << recipe.getPrice() << std::endl;
        std::cout << "Tiempo de Preparación: " << recipe.getPrepTime() << std::endl;
        std::cout << "Ingredientes:" << std::endl;
        for (const auto& pair : recipe.getIngredients()) {
            std::cout << "  " << pair.first << ": " << pair.second << std::endl;
        }
        std::cout << "-----------------------------" << std::endl;
    }
}