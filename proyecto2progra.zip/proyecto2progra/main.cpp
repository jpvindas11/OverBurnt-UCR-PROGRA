#include "restaurant.h"
#include <iostream>

int main() {

    Restaurant restaurant(0);

    restaurant.runSimulation();


    return 0;
}
//cd C:\Users\Nardozayer18\Downloads\proyecto2progra
//g++ -o main main.cpp Inventory.cpp
//./main
//para compilar el correcto almacenamiento de la receta en el vector meta en la terminal:
//  g++ -std=c++17 -o main main.cpp Menu.cpp Recipe.cpp
// otra forma:  g++ -o main main.cpp Restaurant.cpp Menu.cpp Recipe.cpp Customer.cpp Inventory.cpp kitchen.cpp table.cpp