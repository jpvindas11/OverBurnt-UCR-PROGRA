#include "Inventory.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <iostream>
#define NOMBRE_ARCHIVO "inventory.csv"
using namespace std;

Inventory::Inventory() {}

void Inventory::loadInventaryCSV() {
    ifstream archivo(NOMBRE_ARCHIVO);
    string linea;
    char delimitador = ',';
     // Leemos la primer línea para descartarla, pues es el encabezado
    getline(archivo, linea);
    // Leemos todas las líneas
    while (getline(archivo, linea)) {
        stringstream stream(linea); // Convertir la cadena a un stream
        string nombre, cantidadStr;
        int cantidad;

        // Extraer todos los valores de esa fila
        getline(stream, nombre, delimitador);
        getline(stream, cantidadStr, delimitador);

        // Verificar si la cadena cantidadStr está vacía o contiene caracteres no numéricos
        try {
            cantidad = stoi(cantidadStr);
        } catch (const invalid_argument& e) {
            cerr << "Error de conversión: '" << cantidadStr << "' no es un número válido." << endl;
            continue; // O manejar el error según lo necesario
        }

        // Almacenar en el map
        ingredients[nombre] = cantidad;

        // Almacenar en el vector
        Ingredient ingredient = {nombre, cantidad};
        ingredientList.push_back(ingredient);
    }

    archivo.close();
}
bool Inventory::hasIngredients(const std::map<std::string, int>& required) const {
    std::cout << "Checking if inventory has required ingredients:" << std::endl;
    
    for (const auto& item : required) {
        auto it = ingredients.find(item.first);
        if (it == ingredients.end()) {
            std::cout << "Ingredient " << item.first << " not found in inventory." << std::endl;
            return false;
        }
        if (it->second < item.second) {
            std::cout << "Not enough " << item.first << ". Required: " << item.second << ", Available: " << it->second << std::endl;
            return false;
        }
    }
    return true;
}

void Inventory::useIngredients(const std::map<std::string, int>& reductionMap) {
    for (const auto& item : reductionMap) {
        auto it = ingredients.find(item.first);
        if (it != ingredients.end() && it->second >= item.second) {
            it->second -= item.second;
        } else {
            throw std::runtime_error("Not enough ingredients: " + item.first);
        }
    }
}

void Inventory::printIngredients() const {
    for (const auto& ingredient : ingredientList) {
        cout << "Ingrediente: " << ingredient.name << ", Cantidad: " << ingredient.amount << endl;
    }
}
