#include "Inventory.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <iostream>
#define NOMBRE_ARCHIVO "inventory.csv"
using namespace std;
Inventory::Inventory() {}

void Inventory::loadInventaryCSV() {
    ifstream archivo(NOMBRE_ARCHIVO);
    string linea;
    char delimitador = ',';
    // Leemos la primer línea para descartarla, pues es el encabezado
    getline(archivo, linea);
    // Leemos todas las líneas
    while (getline(archivo, linea))
    {

        stringstream stream(linea); // Convertir la cadena a un stream
        string nombre,cantidad;
        // Extraer todos los valores de esa fila
        getline(stream, nombre, delimitador);
        getline(stream, cantidad, delimitador);
        
        
        
        // Imprimir
        cout << "Descripcion: " << nombre << endl;
        cout << "cantidad: " << cantidad << endl;
    }

    archivo.close();
}
// Verifica si hay suficientes ingredientes disponibles.
bool Inventory::hasIngredients(const map<string, int>& required) const {
    for (const auto& item : required) {
        auto it = ingredients.find(item.first);
        if (it == ingredients.end() || it->second < item.second) {
            return false;
        }
    }
    return true;
}
//Usa los ingredientes especificados, disminuyendo su cantidad en el inventario.
void Inventory::useIngredients(const map<string, int>& used) {
    for (const auto& item : used) {
        ingredients[item.first] -= item.second;
    }
}
void Inventory::printIngredients() const {
    for (const auto& pair : ingredients) {
        cout << "Ingrediente: " << pair.first << ", Cantidad: " << pair.second << endl;
    }
}
