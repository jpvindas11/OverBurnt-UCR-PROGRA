#include "fila.h"

#include <iostream>

int main() {
    Fila fila;
    fila.generateQueue();
    fila.printCustomers();

    return 0;
    
}
//cd C:\Users\Nardozayer18\Downloads\proyecto2progra
//g++ -o main main.cpp Inventory.cpp
//./main
//para compilar el correcto almacenamiento de la receta en el vector meta en la terminal:
//  g++ -std=c++17 -o main main.cpp Menu.cpp Recipe.cpp
// otra forma:  g++ -o main main.cpp Menu.cpp Recipe.cpp     