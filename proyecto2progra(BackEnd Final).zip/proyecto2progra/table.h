#ifndef TABLE_H
#define TABLE_H

#include <string>
#include <vector>
#include "Customer.h"

class Table {
public:
    // Constructor
    Table(std::string name);

    // Métodos
    bool isAvailable() const;
    bool seatCustomer(Customer* customer);
    void freeTable(std::string name);
    const std::vector<Customer*>& getCustomers() const;
    
    std::string getName() const;
private:
    std::string name;
    bool available;
    std::vector<Customer*> Listcustomers;
};

#endif
