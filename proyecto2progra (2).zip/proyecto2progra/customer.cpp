#include "Customer.h"
using namespace std;
Customer::Customer(string name, const vector<string>& order) : name(move(name)), order(order) {}

string Customer::getName() const {
    return name;
}

vector<string> Customer::getOrder() const {
    return order;
}
//agregar funciones tiempo de llegada y de espera y tiempo comiendo y la visualizacion del customer
// ademas hay que hacer csv de nombres 