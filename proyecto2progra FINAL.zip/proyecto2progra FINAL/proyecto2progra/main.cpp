#include "Restaurant.h"
#include <iostream>
#undef main


int main(int argc, char *argv[]) {


    try {
        // Inicializar el restaurante con 5 mesas y archivos CSV para inventario y menú
        Restaurant restaurant(6);
        restaurant.runSimulation();
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}