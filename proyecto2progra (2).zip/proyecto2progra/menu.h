#ifndef MENU_H
#define MENU_H

#include <vector>
#include "Recipe.h"
using namespace std;

class Menu {
public:
    Menu();
    void loadFromCSV();
    Recipe getRecipe(const string& name) const;

private:
    //recipes: Vector que almacena las recetas disponibles.
    vector<Recipe> recipes;
};
#endif