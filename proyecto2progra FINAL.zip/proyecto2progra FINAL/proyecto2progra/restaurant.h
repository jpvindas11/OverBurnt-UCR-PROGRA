#ifndef RESTAURANT_H
#define RESTAURANT_H


#define SPAWN_RATE 7

#include "Table.h"
#include "Customer.h"
#include "graphics.h"
#include <vector>
#include <queue>
#include "Menu.h"
#include "Inventory.h"
#include "Kitchen.h"
#include "ThreadPool.h"
#include <mutex>



class Restaurant {
public:
    Restaurant(int numTables);
    ~Restaurant(); // Destructor para liberar la memoria de las mesas
    void runSimulation();

private:
    std::vector<Table*> tables;
    std::queue<Customer*> waitingQueue;
    Menu menu;
    Inventory inventory;
    Kitchen kitchen;
    ThreadPool pool;
    Graphics graphics;

    void generateCustomers();
    void assignTables();
    void assignCustomerToTable(Customer* customer);
    void processOrderForTable(Table* table);
    std::mutex kitchenMutex;

};

#endif // RESTAURANT_H
