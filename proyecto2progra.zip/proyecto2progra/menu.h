#ifndef MENU_H
#define MENU_H

#include <map>
#include <vector>
#include <string>
#include "Recipe.h"

class Menu {
public:
    Menu();
    void loadFromCSV();
    Recipe getRecipe(const std::string& name) const;
    void printRecipes() const; // Declaración del nuevo método

private:
    struct Ingredient {
        std::string name;
        double amount;
    };

    std::vector<Recipe> recipesList; // Vector que almacena las recetas disponibles
    std::map<std::string, int> ingredients;
};

#endif