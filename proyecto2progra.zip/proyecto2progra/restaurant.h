#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <vector>
#include <queue>
#include <memory>
#include "Customer.h"
#include "Table.h"
#include "Menu.h"
#include "Inventory.h"
#include "Kitchen.h"
using namespace std;
class Restaurant {
public:
    //Constructor: Recibe el número de mesas y los nombres de los archivos CSV para inventario y menú.

    Restaurant(int numTables);

    void runSimulation();

private:
   vector<unique_ptr<Table>> tables;
    queue<unique_ptr<Customer>> waitingQueue; 
    Menu menu;
    Inventory inventory;
    Kitchen kitchen;


    //tables: Almacena las mesas del restaurante.
    //waitingQueue: Cola de clientes esperando una mesa.
    //menu: Lista de platos disponibles.
    //inventory: Inventario de ingredientes.
    //kitchen: Gestiona la preparación de los platos.

    Customer spawnRandomCustomer();
    
    void handleCustomerArrival();
    void assignTables();
};

#endif