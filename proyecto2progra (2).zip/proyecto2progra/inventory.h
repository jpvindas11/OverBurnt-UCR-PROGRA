#ifndef INVENTORY_H
#define INVENTORY_H

#include <map>
#include <string>
#include <vector>
using namespace std;

class Inventory {
public:
    Inventory();
    void loadInventaryCSV();
    bool hasIngredients(const map<string, int>& required) const;
    void useIngredients(const map<string, int>& used);
    void printIngredients() const;

private:
    struct Ingredient {
        string name;
        int amount;
    };

    map<string, int> ingredients;
    vector<Ingredient> ingredientList;  // Vector para almacenar los ingredientes
};

#endif 
