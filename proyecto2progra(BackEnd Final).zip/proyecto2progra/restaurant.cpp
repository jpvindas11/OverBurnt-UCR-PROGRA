#include "Restaurant.h"
#include "Table.h"
#include "Customer.h"
#include "Kitchen.h"
#include "ThreadPool.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <vector>
#include <functional>
#include <future>
#include <string>

Restaurant::Restaurant(int numTables)
        : menu(), inventory(), kitchen(menu, inventory), pool(std::thread::hardware_concurrency()) {

    for (int i = 0; i < numTables; ++i) {
        tables.push_back(new Table("Table " + std::to_string(i + 1)));
    }
    inventory.loadInventaryCSV();
    menu.loadFromCSV();
}

Restaurant::~Restaurant() {
    for (auto& table : tables) {
        delete table;
    }
}

void Restaurant::runSimulation() {
    while (true) {
        if (waitingQueue.empty()) {
            pool.enqueue([this] { generateCustomers(); });
        }

        pool.enqueue([this] { assignTables(); });

        std::this_thread::sleep_for(std::chrono::seconds(1)); // Simulación de tiempo

        // Procesar pedidos en paralelo para cada mesa
        std::vector<std::future<void>> futures;
        for (auto& table : tables) {
            futures.push_back(pool.enqueue([this, table] { processOrderForTable(table); }));
        }

        // Esperar a que todas las mesas hayan terminado de procesar los pedidos
        for (auto& future : futures) {
            future.get();
        }
    }
}

void Restaurant::generateCustomers() {
    for (int i = 0; i < 36; ++i) {
        waitingQueue.push(new Customer(Customer::spawnRandomCustomer()));
    }
}

void Restaurant::assignTables() {
    while (!waitingQueue.empty()) {
        auto customer = waitingQueue.front();
        waitingQueue.pop();
        assignCustomerToTable(customer);
    }
}

void Restaurant::assignCustomerToTable(Customer* customer) {
    for (auto& table : tables) {
        if (table->isAvailable() && table->getCustomers().size() < 6) {
            while (!waitingQueue.empty() && table->getCustomers().size() < 6) {
                auto nextCustomer = waitingQueue.front();
                waitingQueue.pop();
                table->seatCustomer(nextCustomer);
            }
            std::cout << "Assigned 6 customers to " << table->getName() << ": ";
            const auto& customers = table->getCustomers();
            for (const auto& cust : customers) {
                std::cout << cust->getName();
                if (&cust != &customers.back()) {
                    std::cout << ", ";
                }
            }
            std::cout << std::endl;
            break;
        }
    }
}

void Restaurant::processOrderForTable(Table* table) {
    std::vector<std::vector<std::string>> orders;
    const auto& customers = table->getCustomers();
    for (const auto& customer : customers) {
        orders.push_back(customer->getOrder());
    }

    bool canPrepare;
    {
        std::lock_guard<std::mutex> lock(kitchenMutex); // Bloquear el acceso a la cocina solo para verificar y deducir ingredientes
        canPrepare = kitchen.canPrepareOrders(orders);

    }

    if (canPrepare) {
        std::cout << "Orders for table " << table->getName() << ":\n";
        std::vector<std::future<void>> dishFutures;
        for (const auto& customer : customers) {
            std::vector<std::string> order = customer->getOrder();
            std::cout << "Customer " << customer->getName() << " ordered:";
            for (const auto& item : order) {
                std::cout << " " << item;
                dishFutures.push_back(pool.enqueue([this, item] { kitchen.prepareDish(item); })); // Preparar cada plato en paralelo
            }
            std::cout << std::endl;
        }
        for (auto& future : dishFutures) {
            future.get(); // Esperar a que todos los platos se preparen
        }


        std::vector<int> eatingTimes; // Vector para almacenar los tiempos de comida de un cliente
        const auto& customers = table->getCustomers();
        for (const auto& customer : customers) {
            eatingTimes.push_back(customer->getEatingTime());
        }

        kitchen.eatTimeOfDish(eatingTimes);

        string tableStr=table->getName();
        table->freeTable(tableStr);
    } else {
        string tableStr=table->getName();
        std::cout << "Not enough ingredients to prepare orders for table " << table->getName() << std::endl;
        table->freeTable(tableStr);
    }
}

/*void Restaurant::gettingOrder(Table* table) {
    std::vector<std::vector<std::string>> orders;
    const auto& customers = table->getCustomers();
    for (const auto& customer : customers) {
        orders.push_back(customer->getOrder());
    }

    if (kitchen.canPrepareOrders(orders)) {
        std::cout << "Orders for table " << table->getName() << ":\n";
        for (const auto& customer : customers) {
            std::vector<std::string> order = customer->getOrder();
            std::cout << "Customer " << customer->getName() << " ordered:";
            for (const auto& item : order) {
                std::cout << " " << item;
                kitchen.prepareDish(item);  // Preparar cada plato en la orden
            }
            std::cout << std::endl;
        }
        std::vector<int> eatingTimes; // Vector para almacenar los tiempos de comida de un cliente
        const auto& customers = table->getCustomers();
        for (const auto& customer : customers) {
            eatingTimes.push_back(customer->getEatingTime());

            for (const auto& item : eatingTimes) {
                kitchen.eatTimeOfDish(item);  // Preparar cada plato en la orden
            }
        }
        string tableStr=table->getName();
        table->freeTable(tableStr);
    } else {
        string tableStr=table->getName();
        std::cout << "Not enough ingredients to prepare orders for table " << table->getName() << std::endl;
        table->freeTable(tableStr);
    }
}
 */