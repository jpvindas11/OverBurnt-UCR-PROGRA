#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <vector>

class Customer {
public:
    Customer(const std::string& name, const std::vector<std::string>& order, int eatingTime);
    static Customer spawnRandomCustomer(); // Función estática para generar un Customer aleatorio
    int getNum();
    std::string getName() const;
    std::vector<std::string> getOrder() const;
    int getEatingTime() const;

private:
    std::string name;
    std::vector<std::string> order;
    int eatingTime;
};

#endif