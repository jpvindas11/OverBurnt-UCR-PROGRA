#include "Table.h"

// Constructor
Table::Table(std::string name) : name(name), available(true) {}

// Métodos
bool Table::isAvailable() const {
    return available;
}

bool Table::seatCustomer(Customer* customer) {
    if (Listcustomers.size() < 6) {
        Listcustomers.push_back(customer);
        available = false;
        return true;
    }
    return false; // La mesa está llena, no se pudo sentar al cliente
}

void Table::freeTable(std::string name) {
    Listcustomers.clear();
    available = true;
}
std::string Table::getName() const {
    return name;
}
const std::vector<Customer*>& Table::getCustomers() const {
    return Listcustomers;
}
