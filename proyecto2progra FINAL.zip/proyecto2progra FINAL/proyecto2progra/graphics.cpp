#include "graphics.h"

Graphics::Graphics(){}
Graphics::~Graphics(){}

void Graphics::init(){
    SDL_Init (SDL_INIT_EVERYTHING);

    window = SDL_CreateWindow("HELP",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SCREEN_WIDTH,SCREEN_HEIGHT, SDL_WINDOW_ALLOW_HIGHDPI);
    windowEvent;
    renderer = SDL_CreateRenderer(window,-1,0);

    //TEXTURE LOAD
    logo = load_texture("assets/logo.png",renderer,(SCREEN_WIDTH/2) - (LOGO_WIDTH/2),
    (SCREEN_HEIGHT/2) - (LOGO_HEIGHT*1.5),LOGO_WIDTH, LOGO_HEIGHT, logoR);

    start = load_texture("assets/start.png",renderer,(SCREEN_WIDTH/2) - (START_WIDTH/2),
    (SCREEN_HEIGHT/2) + (START_HEIGHT/4),START_WIDTH, START_HEIGHT, startR);
    startS.x = 0; startS.y = 0;  startS.w = START_WIDTH/2; startS.h = START_HEIGHT/2;

    gui = load_texture("assets/gui.png",renderer,(SCREEN_WIDTH) - (GUI_WIDTH),0
    ,GUI_WIDTH, GUI_HEIGHT, guiR);

    tableT = load_texture("assets/table.png",renderer,256,256
    ,TABLE_WIDTH, TABLE_HEIGHT, tableR);
    tableS.x = 0; tableS.y = 0;  tableS.w = TABLE_WIDTH/2; tableS.h = TABLE_HEIGHT/2; 

    person = load_texture("assets/guys.png",renderer,QUEUE_START_X,QUEUE_START_Y
    ,PERSON_WIDTH, PERSON_HEIGHT, personR);
    personS.x = 0; personS.y = 0;  personS.w = PERSON_WIDTH/2; personS.h = PERSON_HEIGHT/2;

    restaurant = load_texture("assets/restaurant.png",renderer,0,0
    ,RESTAURANT_WIDTH, RESTAURANT_HEIGHT, restaurantR);

    gameState = 0;
    menu = 0;

    isRunning = true;
}

void Graphics::update(std::vector<Table*>& tables, std::queue<Customer*>& queue){
    
    control();
    event();
    render(tables,queue);
}

void Graphics::control(){

    if (gameState == 0){
        //START
        if (select(startR,START_WIDTH,START_HEIGHT) == true){
            startS.x = START_WIDTH/2; //CHANGE SPRITE
            if (click){gameState = 1;}

        } else {startS.x = 0;}
    }
}
void Graphics::render(std::vector<Table*>& tables, std::queue<Customer*>& queue){

    SDL_RenderClear(renderer);

    if (gameState == 0){
        SDL_RenderCopy(renderer, logo, NULL, &logoR);
        SDL_RenderCopy(renderer, start, &startS, &startR);
    }
    else {
        SDL_RenderCopy(renderer, restaurant, NULL, &restaurantR);

        drawTable(tables);  //DRAW TABLE
        //drawQueue(queue); //QUEUE


        SDL_RenderCopy(renderer, gui, NULL, &guiR);
    }

    SDL_RenderPresent(renderer);
}

void Graphics::drawTable(std::vector<Table*>& tables){
    //TABLE
    int index = 0;
    int pIndex = 0;
    for (auto& table : tables){

        if (index == 0){
            tableR.x = TABLE_XPOS1;
            tableR.y = TABLE_YPOS1;
        }
        else if (index == 1){
            tableR.x = TABLE_XPOS2;
            tableR.y = TABLE_YPOS2;
        }
        else if (index == 2){
            tableR.x = TABLE_XPOS3;
            tableR.y = TABLE_YPOS3;
        }
        else if (index == 3){
            tableR.x = TABLE_XPOS4;
            tableR.y = TABLE_YPOS4;
        }
        else if (index == 4){
            tableR.x = TABLE_XPOS5;
            tableR.y = TABLE_YPOS5;
        }
        else if (index == 5){
            tableR.x = TABLE_XPOS6;
            tableR.y = TABLE_YPOS6;
        }

        SDL_RenderCopy(renderer, tableT, &tableS, &tableR);

        pIndex = 0;
        for(auto& customer : table->getCustomers()){
            if (pIndex < 3){
                personR.x = tableR.x-TILE;
                personR.y = tableR.y-TILE*pIndex;
            } else {
                personR.x = tableR.x+TABLE_WIDTH;
                personR.y = tableR.y-TILE*(pIndex-3); 
            }
            SDL_RenderCopy(renderer, person, &personS, &personR);
        }

    }
}

void Graphics::drawQueue(std::queue<Customer*>& queue){
 
    std::queue<Customer*> queueC = queue;
    int index = 0;

    while(!queueC.empty()){ //QUEUE

        personR.x = QUEUE_START_X + TILE * index;
        personR.y = QUEUE_START_Y;

        personS.w = PERSON_WIDTH/2;
        personS.h = PERSON_HEIGHT/2;

        personS.x = (PERSON_WIDTH/2 * queue.front()->getNum());

        SDL_RenderCopy(renderer, person, &personS, &personR);
        index++;
        
        queueC.pop();
    } 
}
void Graphics::event(){

    //CANCEL CLICK
    click = false;

    if (SDL_PollEvent( &windowEvent )){

        if (SDL_QUIT == windowEvent.type){
            isRunning = false;
        }
        if (SDL_MOUSEMOTION == windowEvent.type){
            SDL_GetMouseState(&mouseX, &mouseY);

            std::cout << mouseX << ":" << mouseY << std::endl;
        }
        if (SDL_MOUSEBUTTONDOWN == windowEvent.type){
            if (SDL_BUTTON_LEFT == windowEvent.button.button){

                std::cout << "BUTTON DOWN" << std::endl;
                click = true;
            }
        }
    }


}

void Graphics::clean(){
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
}

SDL_Texture* Graphics::load_texture(const char* texture, SDL_Renderer *ren, int x, int y, int WIDTH, int HEIGHT, SDL_Rect &desR){

    SDL_Surface* tempSurf = IMG_Load(texture);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, tempSurf);
    SDL_FreeSurface(tempSurf);

    desR.w = WIDTH; desR.h = HEIGHT;
    desR.x = x; desR.y = y;

    return tex;
}

bool Graphics::select(SDL_Rect desR, int WIDTH, int HEIGHT){
    if ((mouseX >= desR.x && mouseX <= desR.x + WIDTH)
    && (mouseY >= desR.y && mouseY <= desR.y + HEIGHT)){ 
        return true;
    } else {return false;}
}