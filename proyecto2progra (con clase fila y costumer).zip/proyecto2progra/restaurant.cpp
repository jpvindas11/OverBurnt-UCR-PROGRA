#include "Restaurant.h"
#include "menu.h"
#include "inventory.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;
Restaurant::Restaurant(int numTables, const string& inventoryFile, const string& menuFile)
    : menu(), inventory(), kitchen(menu, inventory) {
    
    for (int i = 0; i < numTables; ++i) {
        tables.push_back(make_unique<Table>(i));
        // se crean las mesas y se añaden a la lista
        //cada mesa se gestiona de manera única
    }
    // Cargar inventario y menú
    inventory.loadInventaryCSV();//inventory
    menu.loadFromCSV(); //menu
}

void Restaurant::runSimulation() {
    
}

void Restaurant::handleCustomerArrival() {
    // llegada de nuevos clientes
    //hay que generarlos con el spawn
}

void Restaurant::assignTables() {
    // clientes a mesas disponibles
}

