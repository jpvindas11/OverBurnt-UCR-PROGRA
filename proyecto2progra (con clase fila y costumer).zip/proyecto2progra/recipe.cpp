#include "Recipe.h"

Recipe::Recipe(const std::string& name, double price, double prepTime, double eatingTime, const std::map<std::string, int>& ingredients)
    : name(name), price(price), prepTime(prepTime), eatingTime(eatingTime), ingredients(ingredients) {}

std::string Recipe::getName() const {
    return name;
}

double Recipe::getPrice() const {
    return price;
}

double Recipe::getPrepTime() const {
    return prepTime;
}

double Recipe::getEatingTime() const {
    return eatingTime;
}

std::map<std::string, int> Recipe::getIngredients() const {
    return ingredients;
}