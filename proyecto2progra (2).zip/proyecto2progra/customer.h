#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <vector>
using namespace std;
class Customer {
public:
    //recibe en el costructor el nombre del cliente y la orden
    
    Customer(string name, const vector<string>& order);
    string getName() const;
    vector<std::string> getOrder() const;

private:
    string name;
    vector<string> order;
};

#endif