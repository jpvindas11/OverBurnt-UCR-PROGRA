#include "Table.h"
using namespace std;
//Inicializa la mesa como disponible y sin cliente asignado.
Table::Table(string name) :name(name), available(true), customer(nullptr) {

}


bool Table::isAvailable() const {
    return available;
}

void Table::seatCustomer(unique_ptr<Customer> customer) {
    this->customer = move(customer);//mesa tomará la propiedad exclusiva del objeto Customer
    available = false;//aqui ya se sento, la mesa esta ocupada
}

void Table::freeTable() {
    customer.reset();
    available = true;
}

Customer* Table::getCustomer() const {
    return customer.get();
}