#include "Kitchen.h"
#include <iostream>
#include <thread>
#include <chrono>
using namespace std;
Kitchen::Kitchen(Menu& menu, Inventory& inventory) : menu(menu), inventory(inventory) {}

void Kitchen::prepareDish(const string& recipeName) {
    Recipe recipe = menu.getRecipe(recipeName);
   
    inventory.useIngredients(recipe.getIngredients());
    cout << "Preparing " << recipeName << endl;
    
    // Obtener el tiempo estimado de preparación de la receta
    double prepTime = recipe.getPrepTime();
    
    //tiempo de preparación podría aumentar o disminuir en un 10% como máximo.
    double PREP_DELAY=0.1;

    // Calcular un valor aleatorio entre -1 y 1
    int randomMultiplier = (rand() % 3) - 1; // Genera números entre -1 y 1
    
    // Calcular el tiempo ajustado de preparación según la fórmula
    double adjustedPrepTime = prepTime + (prepTime * randomMultiplier * PREP_DELAY);
    
    //tiempo minimo de preparacion vamos a decir que es 5 min
    int MIN_PREP_TIME=5;
    // Verificar si el tiempo calculado es negativo y ajustarlo si es necesario
    if (adjustedPrepTime < MIN_PREP_TIME) {
        adjustedPrepTime = MIN_PREP_TIME;
    }
    
    // Simular el tiempo de preparación
    this_thread::sleep_for(chrono::milliseconds(static_cast<int>(adjustedPrepTime * 1000)));
    
    cout << recipeName << " is ready!" << endl;
}

bool Kitchen::canPrepareOrders(const std::vector<std::vector<std::string>>& orders) {
    // Mapa para almacenar la cantidad total de ingredientes necesarios
    std::map<std::string, int> totalIngredientsNeeded;

    // Recorrer todas las órdenes de la mesa
    for (const auto& order : orders) {
        for (const auto& dish : order) {
            // Obtener la receta del plato
            Recipe recipe = menu.getRecipe(dish);
            // Obtener los ingredientes de la receta
            const auto& ingredients = recipe.getIngredients();
            // Sumar los ingredientes al total
            for (const auto& ingredient : ingredients) {
                totalIngredientsNeeded[ingredient.first] += ingredient.second;
            }
        }
    }

    bool cont=inventory.hasIngredients(totalIngredientsNeeded);

    if(inventory.hasIngredients(totalIngredientsNeeded)){
        inventory.useIngredients(totalIngredientsNeeded);
    }

    return cont;
}

void Kitchen::eatTimeOfDish(const std::vector<int>& eatingTimes) {
    bool finishedEating = false;

    // Encontrar el tiempo de comida más largo en el vector de tiempos de comida
    int total_eating_time_ms = 0;
    for (int time : eatingTimes) {
        if (time > total_eating_time_ms) {
            total_eating_time_ms = time;
        }
    }

    // Iniciar un temporizador para el tiempo de comida
    auto start_time = std::chrono::steady_clock::now();

    // Mientras no se haya completado el tiempo de comida
    while (std::chrono::steady_clock::now() - start_time < std::chrono::milliseconds(total_eating_time_ms)) {
        // Simular el acto de comer esperando 1 segundo
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    // Cuando se complete el tiempo de comida, actualizar el estado del cliente
    finishedEating = true;
}