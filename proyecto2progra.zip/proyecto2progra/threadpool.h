#ifndef THREADPOOL_H
#define THREADPOOL_H

#include <vector>
#include <thread>
#include <mutex>
#include <queue>
#include <functional>
#include <iostream>
#include <condition_variable>
#include <future>
#include <stdexcept>

// Class declaration for ThreadPool

class ThreadPool {
public:
    // Constructor for ThreadPool, initializes with a default pool size equal to hardware concurrency
    ThreadPool(size_t pool_size = std::thread::hardware_concurrency())
        : stop(false) {
        // Create worker threads equal to the specified pool size
        for (size_t i = 0; i < pool_size; ++i) {
            // Each worker thread executes a lambda function
            workers.emplace_back([this] {
                // Loop indefinitely until the ThreadPool is stopped
                while (true) {
                    std::function<void()> task;
                    {
                        // Lock the queue mutex to access the task queue safely
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        // Wait until either there is a task in the queue or the ThreadPool is stopped
                        this->condition.wait(lock, [this] {
                            return this->stop || !this->tasks.empty();
                        });
                        // If the ThreadPool is stopped and there are no tasks, exit the thread
                        if (this->stop && this->tasks.empty())
                            return;
                        // Get the next task from the queue
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }
                    // Execute the task
                    task();
                }
            });
        }
    }

    // Function template to enqueue a task with specified arguments and return a future for its result
    template <class F, class... Args>
    auto enqueue(F&& f, Args&&... args)
        -> std::future<typename std::result_of<F(Args...)>::type> {
        using return_type = typename std::result_of<F(Args...)>::type;

        // Create a packaged task from the provided function and arguments
        auto task = std::make_shared<std::packaged_task<return_type()>>(
            std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );

        // Get a future for the result of the task
        std::future<return_type> res = task->get_future();
        {
            // Lock the queue mutex to safely enqueue the task
            std::unique_lock<std::mutex> lock(queue_mutex);
            // If the ThreadPool is stopped, throw an exception
            if (stop)
                throw std::runtime_error("enqueue on stopped ThreadPool");
            // Enqueue the task
            tasks.emplace([task]() { (*task)(); });
        }
        // Notify one waiting thread that a new task is available
        condition.notify_one();
        return res;
    }

    // Destructor for ThreadPool
    ~ThreadPool() {
        {
            // Lock the queue mutex to safely set the stop flag
            std::unique_lock<std::mutex> lock(queue_mutex);
            stop = true;
        }
        // Notify all waiting threads that the ThreadPool is stopped
        condition.notify_all();
        // Join all worker threads
        for (std::thread &worker : workers)
            worker.join();
    }

private:
    // Private member variables for ThreadPool
    std::vector<std::thread> workers; // Vector to store worker threads
    std::queue<std::function<void()>> tasks; // Queue to store tasks

    std::mutex queue_mutex; // Mutex to synchronize access to the task queue
    std::condition_variable condition; // Condition variable for synchronization
    bool stop; // Flag to indicate if the ThreadPool should stop
};

#endif // THREADPOOL_H
