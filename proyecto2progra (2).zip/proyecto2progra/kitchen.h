#ifndef KITCHEN_H
#define KITCHEN_H

#include "Menu.h"
#include "Inventory.h"
#include <string>
using namespace std;
class Kitchen {
public:
    Kitchen(Menu& menu, Inventory& inventory);
    void prepareDish(const string& recipeName);

private:
    Menu& menu;
    Inventory& inventory;
};

#endif