#include "Menu.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#define NOMBRE_ARCHIVO "recipes.csv"

using namespace std;
Menu::Menu() {}


void Menu::loadFromCSV(){
    ifstream archivo(NOMBRE_ARCHIVO);
    string linea;
    char delimitador = ',';

    // Leemos todas las líneas
    while (getline(archivo, linea)) {
        stringstream stream(linea); // Convertir la cadena a un stream
        string nombreReceta;
        double precio;
        int tiempoPreparacion, tiempoComer;

        // Extraer nombre de receta, precio y tiempos
        getline(stream, nombreReceta, delimitador);
        stream >> precio;
        stream.ignore(); // Ignorar la coma
        stream >> tiempoPreparacion;
        stream.ignore(); // Ignorar la coma
        stream >> tiempoComer;
        stream.ignore(); // Ignorar la coma

        // Imprimir detalles de la receta
        cout << "==================" << endl;
        cout << "Receta: " << nombreReceta << endl;
        cout << "Precio: " << precio << endl;
        cout << "Tiempo de preparacion: " << tiempoPreparacion << " min" << endl;
        cout << "Tiempo de comer: " << tiempoComer << " min" << endl;

        // Leer los ingredientes y sus cantidades
        string ingrediente;
        int cantidad;
        while (getline(stream, ingrediente, delimitador)) {
            stream >> cantidad;
            stream.ignore(); // Ignorar la coma
            cout << "Ingrediente: " << ingrediente << ", Cantidad: " << cantidad << endl;
        }
    }

    archivo.close();

    
}

Recipe Menu::getRecipe(const string& name) const { //en el parametro recibe el nombre de la receta que se está buscando.
    for (const auto& recipe : recipes) { //busca en el vector de recipes
        if (recipe.getName() == name) { //si se encontró
            return recipe;
        }
    }
    throw runtime_error("Recipe not found"); //si no estaba
}