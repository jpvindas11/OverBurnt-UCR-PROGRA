#ifndef TABLE_H
#define TABLE_H

#include <memory>
#include "Customer.h"
#include <string>
using namespace std;
class Table {
public:
    //Constructor: Recibe un ID para la mesa.
    //isAvailable(): Retorna si la mesa está disponible.
    //seatCustomer(): Asigna un cliente a la mesa.
    //freeTable(): Libera la mesa.
    //getCustomer(): Retorna el cliente asignado a la mesa.

    Table(string name);
    bool isAvailable() const;
    void seatCustomer(unique_ptr<Customer> customer);//puntero único a un objeto Customer
    void freeTable();
    Customer* getCustomer() const;// acceso al cliente sentado

private:
    string name;
    bool available;
    unique_ptr<Customer> customer;//apunta al cliente actualmente sentado en la mesa.
};
// agregar tiempo de espera en la mesa

#endif