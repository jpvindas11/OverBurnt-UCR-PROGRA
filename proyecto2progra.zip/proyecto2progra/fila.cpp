#include "Fila.h"
#include "Customer.h"
#include <iostream>

Fila::Fila() {}

void Fila::generateQueue() {
    
    for (int i = 0; i < 10; ++i) {
        waitingQueue.push(std::make_unique<Customer>(Customer::spawnRandomCustomer()));
    }
}

void Fila::printCustomers() const {
    // No se puede iterar directamente sobre std::queue, así que haremos una copia
    std::queue<std::unique_ptr<Customer>> tempQueue = waitingQueue;
    while (!tempQueue.empty()) {
        const Customer& customer = *tempQueue.front();
        std::cout << "Customer Name: " << customer.getName() << std::endl;
        std::cout << "Order: ";
        for (const auto& item : customer.getOrder()) {
            std::cout << item << " ";
        }
        std::cout << std::endl;
        std::cout << "Eating Time: " << customer.getEatingTime() << " minutes" << std::endl;
        std::cout << "-------------------" << std::endl;
        tempQueue.pop();
    }
}

