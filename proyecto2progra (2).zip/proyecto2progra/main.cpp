#include <iostream>
#include <sstream>
#include <fstream>
#define NOMBRE_ARCHIVO "recipes.csv"
using namespace std;

int main()
{
    ifstream archivo(NOMBRE_ARCHIVO);
    string linea;
    char delimitador = ',';
    // Leemos la primer línea para descartarla, pues es el encabezado
    getline(archivo, linea);
    // Leemos todas las líneas
    while (getline(archivo, linea))
    {

        stringstream stream(linea); // Convertir la cadena a un stream
        string cantidad, tempoPrep, nombre, precioCompra, precioVenta, existencia, stock;
        // Extraer todos los valores de esa fila
        getline(stream, cantidad, delimitador);
        getline(stream, tempoPrep, delimitador);
        getline(stream, nombre, delimitador);
        getline(stream, precioCompra, delimitador);
        getline(stream, precioVenta, delimitador);
        getline(stream, existencia, delimitador);
        getline(stream, stock, delimitador);
        // Imprimir
        cout << "==================" << endl;
        cout << "cantidad: " << cantidad << endl;
        cout << "tempoPrep: " << tempoPrep << endl;
        cout << "Descripcion: " << nombre << endl;
        cout << "Precio de compra: " << precioCompra << endl;
        //cout << "Precio de venta: " << precioVenta << endl;
        //cout << "Existencia: " << existencia << endl;
        //cout << "Stock: " << stock << endl;
    }

    archivo.close();
}
