#ifndef GRAPHICS_H
#define GRAPHICS_H

#define TILE 32
#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 576

#define RESTAURANT_WIDTH 786
#define RESTAURANT_HEIGHT 576

#define LOGO_WIDTH 344
#define LOGO_HEIGHT 144

#define START_WIDTH 344
#define START_HEIGHT 144

#define GUI_WIDTH 256
#define GUI_HEIGHT 576

#define TABLE_WIDTH 64
#define TABLE_HEIGHT 96

#define PERSON_WIDTH 32
#define PERSON_HEIGHT 32

#define QUEUE_START_X 3*TILE 
#define QUEUE_START_Y 16*TILE

#define TABLE_XPOS1 10*TILE
#define TABLE_YPOS1 5*TILE

#define TABLE_XPOS2 15*TILE
#define TABLE_YPOS2 5*TILE

#define TABLE_XPOS3 20*TILE
#define TABLE_YPOS3 5*TILE

#define TABLE_XPOS4 10*TILE
#define TABLE_YPOS4 10*TILE

#define TABLE_XPOS5 15*TILE
#define TABLE_YPOS5 10*TILE

#define TABLE_XPOS6 20*TILE
#define TABLE_YPOS6 10*TILE



#include "sdl/SDL.h"
#include "sdl/SDL_image.h"
#include "iostream"
#include "string"
#include <vector>
#include <queue>
#include "customer.h"
#include "table.h"



class Graphics{

public:

    Graphics();
    ~Graphics();

    void init();
    void update(std::vector<Table*>& tables,std::queue<Customer*>& queue);
    void control();
    void render(std::vector<Table*>& tables,std::queue<Customer*>& queue);
    void event();
    void clean();

    void drawTable(std::vector<Table*>& tables);
    void drawQueue(std::queue<Customer*>& queue);

    bool select(SDL_Rect desR, int WIDTH, int HEIGHT);
    SDL_Texture* load_texture(const char* texture, SDL_Renderer *ren, int x, int y, int WIDTH, int HEIGHT, SDL_Rect &desR);
    bool running() { return isRunning; }

private:

    SDL_Window *window;
    SDL_Event windowEvent;
    SDL_Renderer *renderer;

    SDL_Texture* restaurant;
    SDL_Rect restaurantR;

    SDL_Texture* logo;
    SDL_Rect logoR;

    SDL_Texture* start;
    SDL_Rect startR;
    SDL_Rect startS;

    SDL_Texture* gui;
    SDL_Rect guiR;

    SDL_Texture* tableT;
    SDL_Rect tableR;
    SDL_Rect tableS;

    SDL_Texture* person;
    SDL_Rect personR;
    SDL_Rect personS;

    bool isRunning;
    bool click;

    int gameState; //0 MAIN MENU, 1 GAME
    int menu; //0 NOTHING

    int mouseX, mouseY;

    //TTF_Font* Font = TTF_OpenFont("Roboto.ttf",16);
    //SDL_Color Black {0,0,0};

};

#endif 