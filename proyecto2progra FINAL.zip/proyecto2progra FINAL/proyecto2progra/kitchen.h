#ifndef KITCHEN_H
#define KITCHEN_H

#include "Menu.h"
#include "Inventory.h"
#include <string>
using namespace std;
class Kitchen {
public:

    Kitchen(Menu& menu, Inventory& inventory);
    void prepareDish(const string& recipeName);
    bool canPrepareOrders(const std::vector<std::vector<std::string>>& orders);
    void eatTimeOfDish(const std::vector<int>& eatingTimes);

private:
    Menu& menu;
    Inventory& inventory;
};

#endif